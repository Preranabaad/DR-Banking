package com.lti.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.Account_details;
import com.lti.model.Beneficiary;
import com.lti.model.Drtransactions;
import com.lti.service.TransactionService;
import com.lti.service.UserService;

@Controller
public class TransactionController {
	@Autowired
	private TransactionService tservice;
	@Autowired
	private UserService userservice;
	@Autowired
	private MailSender mailSender;
	@Autowired
	private SimpleMailMessage message;
	
	
	@RequestMapping(path="transaction")
	public String checkBalance(@RequestParam("custid") long custid,@RequestParam("balance") double balance,@RequestParam("baccid") long beneficiaryid ,@RequestParam("remark") String remark ,@RequestParam("amount") double amount,Model model,HttpSession session ){
		if(balance>=amount)
		{
			   int otp   =(int) (Math.random()*9000)+1000;   
			String email =userservice.getemail(custid);
			message.setTo(email); //set a proper recipient of the mail
			message.setSubject("Your One Time Password");
			message.setText("OTP:"+otp);
			mailSender.send(message);
			session.setAttribute("otp", otp);
			Beneficiary ben = userservice.getbeneficiary(beneficiaryid);
			Account_details acc=userservice.getAccount(custid);
			ben.setAmount(amount);
			session.setAttribute("remark", remark);
			
			model.addAttribute("account", acc);
			model.addAttribute("beneficiary", ben);		
			return "PaymentGateway";
		}
		return "Error";
		
	}
	
	
	@RequestMapping(path = "performtransaction")
	public String performtransaction(@RequestParam("tpin") int tpin,@RequestParam("onetime") int onetime,HttpSession session,@RequestParam("accno") long accno, @RequestParam("benaccno") long benaccno, @RequestParam("amount") double amount,@RequestParam("baccname") String bname,Model model)
	{
		String remark=(String) session.getAttribute("remark");
		String type=(String) session.getAttribute("type");
		String username=(String) session.getAttribute("username");
		int otp=(int) session.getAttribute("otp");
		if(otp==onetime)
		{
		boolean result=tservice.validatepin(tpin,username);
		if(result)
		{
			Drtransactions transaction=tservice.performtransaction(amount,benaccno,accno,remark,type);
			model.addAttribute("transaction", transaction);
			
			return "SuccessfullTransaction";
		}
		}
		return "TransactionFailed";
	}
	
	@RequestMapping(path="EndOfTransaction")
	public String EndOfTransaction(HttpSession session){
		tservice.flushentity();
		session.invalidate();
		return "EndOfTransaction";
	}

}
