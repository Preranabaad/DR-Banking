package com.lti.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.text.AbstractDocument.Content;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lti.service.LoginService;
import com.lti.service.UserService;

@Controller

public class LoginController {
	@Autowired
	private LoginService service;
	
	
	
	@RequestMapping(path = "/")
	public String UserloginPage() {
		return "Home";
	}
	@RequestMapping(path = "loginpage")
	public String LoginPage()
	{
		return "Login";
	}
	@RequestMapping(path = "login.do", method = RequestMethod.POST)
	public String Userlogin(@RequestParam("username") String username, @RequestParam("password") String password,HttpServletRequest request, HttpSession session) {
		boolean result = service.readUserLogin(username, password);
		if (result) {
			request.getSession();
			session.setAttribute("username", username);
			return "redirect: addbeneficiarypage";
		}
		return "redirect: loginpage";
	}

	@RequestMapping(path="registeruser")
	public String RegisterIBPage()
	{
		return "RegisterForIB";
	}
	@RequestMapping(path = "AdminLoginPage")
	public String AdminloginPage() {
		return "AdminLogin";
	}

	@RequestMapping(path="Adminlogin", method = RequestMethod.POST)
	public String AdminLogin(@RequestParam("email") String email, @RequestParam("password") String password){
		boolean result= service.readAdminLogin(email,password);
		if (result) {
			return "AdminDashBoard";
		}
		return "redirect: AdminLoginPage";
	}
	
	  @RequestMapping(value="logout",method = RequestMethod.GET)
      public String logout(HttpServletRequest request){
          HttpSession httpSession = request.getSession();
          httpSession.invalidate();
          return "redirect:/";
      }
}



