package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lti.model.dr_Customers;
import com.lti.service.AdminService;



@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminservice;
	

	
@RequestMapping(path="viewallcustomers.do", method=RequestMethod.GET)
	
	public String ViewAllUsers(Model model){
		List<dr_Customers> list=adminservice.viewAllUsers();
		model.addAttribute("customerlist", list);
		return "ViewAllCustomers";
		
	}
	
	
	@RequestMapping(path="validate.do", method=RequestMethod.GET)
	
	public String validateCustomer(Model model){
		List<dr_Customers> list=adminservice.validateCustomer();
		model.addAttribute("customerlist", list);
		return "ValidateCustomer";
		
	}
	
	
	
	@RequestMapping(path="modifyStatus", method=RequestMethod.GET)
	
	public String setStatus(@RequestParam("customerid")long customer_id ){
		int result = adminservice.setStatus(customer_id);
		if(result==1){
			return "redirect: validate.do";
		}
		else{
			return "redirect: validate.do";
		}
		
	
	
	}
	
}
