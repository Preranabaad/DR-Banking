package com.lti.service;

import java.util.List;

import com.lti.model.dr_Customers;

public interface AdminService {

	public List<dr_Customers> viewAllUsers();
	public List<dr_Customers> validateCustomer();
	public  int setStatus(long customer_id);
		
	
}
