package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.UserDao;
import com.lti.model.Beneficiary;
import com.lti.model.dr_Customers;
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao dao;
	
	public UserDao getDao() {
		return dao;
	}
	public void setDao(UserDao dao) {
		this.dao = dao;
	}
	public boolean CheckUsername(String username)
	{
		return dao.CheckUsername(username);
	}
	@Override
	public boolean CheckAccno(double accno) {
		return dao.checkacc(accno);
	
	}
	@Override
	@Transactional
	public void adduser(double accno, String username, String password, int pin) {
	dao.addaccount(accno, username, password, pin);
		
	}
	@Override
	@Transactional
	public void readBeneficiary(String bname, long baccno, String bIFSC, String nickname, String username) {	
		dao.createBeneficiary(bname,baccno,bIFSC,nickname,username);
	}
	
	@Override
	@Transactional
	public boolean addCustomer(dr_Customers customer) {
		int result = dao.createCustomer(customer);
		if(result == 1){
			return true;
		}else{
			return false;
		}
		
	}
	@Override
	public List<Beneficiary> findAllBeneficiary(String username) {
		List<Beneficiary> list = getDao().readAllBeneficiary(username);
		return list;
		
	}

}
