package com.lti.service;

import java.util.List;

import com.lti.model.Beneficiary;
import com.lti.model.dr_Customers;

public interface UserService {
	public boolean CheckUsername(String username);
	public boolean CheckAccno(double accno);
	public void adduser(double accno,String username, String password, int pin);
	public void readBeneficiary(String bname, long baccno, String bIFSC, String nickname, String username);
	public boolean addCustomer(dr_Customers customer);
	public List<Beneficiary> findAllBeneficiary(String username);
}
