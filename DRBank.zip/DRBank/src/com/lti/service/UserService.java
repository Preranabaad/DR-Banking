package com.lti.service;

import java.util.List;

import com.lti.model.Account_details;
import com.lti.model.Beneficiary;
import com.lti.model.Drtransactions;
import com.lti.model.dr_Customers;

public interface UserService {
	public boolean CheckUsername(String username);
	public boolean CheckAccno(long accno);
	public void adduser(long accno,String username, String password, int pin);
	public void readBeneficiary(String bname, long baccno, String bIFSC, String nickname, String username);
	public boolean addCustomer(dr_Customers customer);
	public List<Beneficiary> findAllBeneficiary(String username);
	public Beneficiary getbeneficiary(long beneficiaryid);
	public Account_details getAccount(long custid);
	public String getemail(long custid);
	public boolean removeAccount(String username);
	public dr_Customers viewCustomer(dr_Customers customer,String username);
	public boolean updateCustomerDetails(dr_Customers customer,String username);
	public List<Beneficiary> viewAllBeneficiary(String username);
	public int removeBeneficiary(long beneficiary_Id);
	public List<Drtransactions> readAllTransaction(String username);
	
	
}
