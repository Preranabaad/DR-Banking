package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.LoginDao;
import com.lti.model.Banker_Info;
import com.lti.model.Internet_banking;
@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	private LoginDao dao;
	@Override
	public boolean readUserLogin(String username, String password) {
		int userlist=dao.UserLogin(username, password);
		/*for(Internet_banking i: userlist)
		{
			if(i.getLock_status()==0)
			{
				return true;
			}
		}*/
		return true;
	}
	@Override
	public void CreateUserIb(String username,double accno, String password, int pin) {
		// TODO Auto-generated method stub
		
	}
	
	public boolean readAdminLogin(String email, String password) {
		int userlist=dao.AdminLogin(email, password);
			if(userlist==1)
			{
				return false;
			}
	
		return true;
	}

}
