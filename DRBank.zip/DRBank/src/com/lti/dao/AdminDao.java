package com.lti.dao;

import java.util.List;

import com.lti.model.dr_Customers;

public interface AdminDao {

	public List<dr_Customers> readAllUsers();
	public List<dr_Customers> validateUsers();
	public int updateStatus(long customer_id);
	public int addAccountDetails(long customer_id);
}
