package com.lti.dao;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Account_details;
import com.lti.model.dr_Customers;

@Repository
public class AdminDaoImpl implements AdminDao {
	@PersistenceContext
	@Autowired
	private EntityManager entitymanager;
	
	@Autowired
	private Account_details accDetails;
	

	
	@Override
	public List<dr_Customers> readAllUsers() {
		String jpql="select d From dr_Customers d";
		TypedQuery<dr_Customers> tquery=entitymanager.createQuery(jpql,dr_Customers.class);
		List<dr_Customers>list=tquery.getResultList();
		return list;
		
	}




	@Override
	public List<dr_Customers> validateUsers() {
		String jpql="select d From dr_Customers d where d.status=1";
		
	
		TypedQuery<dr_Customers> tquery=entitymanager.createQuery(jpql,dr_Customers.class);
	
		List<dr_Customers>list=tquery.getResultList();
		return list;
	}



	@Override
	public int updateStatus(long customer_id) {
		
		dr_Customers tempcust= entitymanager.find(dr_Customers.class,customer_id);
		tempcust.setStatus("0");
		entitymanager.merge(tempcust);
		return 1;
	}




	@Override
	public int addAccountDetails(long customer_id) {
		dr_Customers tempcust= entitymanager.find(dr_Customers.class,customer_id);
		accDetails.setAcc_status(0);
		accDetails.setAcc_type(tempcust.getAcc_type());
		accDetails.setIfsc(tempcust.getIFSC());
		accDetails.setBalance(0);
		accDetails.setCustomer_id(customer_id);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		String todayAsString = dtf.format(localDate);
		accDetails.setDateofcreation(todayAsString);
		
		entitymanager.persist(accDetails);
		return 1;
	}
	

}
