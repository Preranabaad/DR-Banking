package com.lti.dao;

import java.util.List;

import com.lti.model.Banker_Info;
import com.lti.model.Internet_banking;

public interface LoginDao {
public int UserLogin(String username,String password);
public int AdminLogin(String username,String password);
}
