package com.lti.dao;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Account_details;
import com.lti.model.Beneficiary;

import com.lti.model.Internet_banking;
import com.lti.model.dr_Customers;

@Repository
public class UserDaoImpl implements UserDao {
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	private Internet_banking ib;
	
	@Autowired
	private Beneficiary beneficiary;
	public boolean CheckUsername(String username)
	{
		
		TypedQuery<Internet_banking> tquery=entityManager.createQuery("Select a from Internet_banking a where a.username=:u",Internet_banking.class);
		tquery.setParameter("u", username);
		List<Internet_banking> acc= tquery.getResultList();
		if(acc.size()==0)
		{
			return true;
		}
		return false;
	}
	@Override
	public boolean checkacc(double accno) {
		TypedQuery<Account_details> tquery=entityManager.createQuery("Select a from Account_details a where a.acc_no=:acc", Account_details.class);
		tquery.setParameter("acc", accno);
		List<Account_details> acc= tquery.getResultList();
		if(acc.size()==0)
		{
			return true;
		}
		return false;
	}
	@Override
	public void addaccount(double accno,String username, String password, int pin) {
		TypedQuery<Account_details> tquery=entityManager.createQuery("Select a from Account_details a where a.acc_no=:acc", Account_details.class);
		tquery.setParameter("acc", accno);
		List<Account_details> acc= tquery.getResultList();
		for(Account_details ac:acc)
		{
			long cid=ac.getCustomer_id();
			ib.setCustomer_id(cid);
			ib.setLock_status(0);
			ib.setPassword(password);
			ib.setPin(pin);
			ib.setUsername(username);
			entityManager.persist(ib);
			
		}
		
		
		
		
	}
	@Override
	public void createBeneficiary(String bname, long baccno, String bIFSC, String nickname, String username) {
		TypedQuery<Internet_banking> tquery=entityManager.createQuery("Select i from Internet_banking i where i.username=:uname", Internet_banking.class);
		tquery.setParameter("uname", username);
		List<Internet_banking> list= tquery.getResultList();
		for(Internet_banking i: list){
			long id= i.getCustomer_id();
			beneficiary.setAmount(0);
			beneficiary.setBeneficiary_IFSC(bIFSC);
			beneficiary.setBeneficiary_name(bname);
			beneficiary.setNick_Name(nickname);
			beneficiary.setBeneficiary_Acc_No(baccno);
			beneficiary.setCustomer_Id(id);
			entityManager.persist(beneficiary);
		}
	}
	@Override
	public int createCustomer(dr_Customers customer) {
		entityManager.persist(customer);
		return 1;
	}
	@Override
	public List<Beneficiary> readAllBeneficiary(String username) {
		TypedQuery<Internet_banking> tquery=entityManager.createQuery("Select i from Internet_banking i where i.username=:uname", Internet_banking.class);
		tquery.setParameter("uname", username);
		List<Internet_banking> list= tquery.getResultList();
		for(Internet_banking i: list){
			long id= i.getCustomer_id();
			String jpql = "Select Nick_Name From Beneficiary b where b.customer_id:i ";
			TypedQuery<Beneficiary> query = entityManager.createQuery(jpql, Beneficiary.class);	
			query.setParameter("i",id);
			List<Beneficiary> qlist = query.getResultList();
			return qlist;
		}
		return null;
	}
	
}
