package com.lti.dao;

import java.util.List;

import com.lti.model.Account_details;
import com.lti.model.Beneficiary;
import com.lti.model.Drtransactions;
import com.lti.model.dr_Customers;

public interface UserDao {
	public boolean CheckUsername(String username);

	public boolean checkacc(long accno);
	public void addaccount(long accno,String username,String password,int pin);

	public void createBeneficiary(String bname, long baccno, String bIFSC, String nickname, String username);
	public int createCustomer(dr_Customers customer);
	public List<Beneficiary> readAllBeneficiary(String username);

	public Beneficiary getbeneficiary(long beneficiaryid);

	public Account_details getAccount(long custid);

	public String getuseremail(long custid);
	public boolean removeUserAccount(String username);
	public dr_Customers viewCustomer(dr_Customers customer,String username);

	public int modifyCustomerDetails(dr_Customers customer,String username);

	public int deleteBeneficiary(long beneficiary_Id);

	public List<Drtransactions> viewAllTransaction(String username);

	
}
