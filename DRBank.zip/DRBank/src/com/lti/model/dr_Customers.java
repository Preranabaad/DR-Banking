package com.lti.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lti.service.AdminService;

@Component
@Entity
@Table(name="DR_CUSTOMERS")
@SequenceGenerator(name="cust_seq", sequenceName="DR_CUSTOMERID_SEQ" ,initialValue=100)
public class dr_Customers implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="cust_seq")
	private long customer_id;
	private String firstname;
	private String lastname;
	private String middlename;
	private String email;
	private String dateofbirth;
	private long mobile;
	private String gender;
	private String PERMANENT_ADDRESS;
	private String CORRESPONDING_ADDRESS;
	private String aadhar_no;
	private String acc_type;
	private String IFSC;
	private String photo_path;
	private String aadhar_path;
	private String status;
	private String reason;
	

	
	
	public dr_Customers() {
		super();
	}


	public dr_Customers(long customer_id, String firstname, String lastname, String middlename, String email,
			String dateofbirth, long mobile, String gender, String pERMANENT_ADDRESS, String cORRESPONDING_ADDRESS,
			String aadhar_no, String acc_type, String iFSC, String photo_path, String aadhar_path, String status,
			String reason) {
		super();
		this.customer_id = customer_id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.middlename = middlename;
		this.email = email;
		this.dateofbirth = dateofbirth;
		this.mobile = mobile;
		this.gender = gender;
		PERMANENT_ADDRESS = pERMANENT_ADDRESS;
		CORRESPONDING_ADDRESS = cORRESPONDING_ADDRESS;
		this.aadhar_no = aadhar_no;
		this.acc_type = acc_type;
		IFSC = iFSC;
		this.photo_path = photo_path;
		this.aadhar_path = aadhar_path;
		this.status = status;
		this.reason = reason;
	}


	public long getCustomer_id() {
		return customer_id;
	}


	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}


	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getMiddlename() {
		return middlename;
	}


	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getDateofbirth() {
		return dateofbirth;
	}


	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}


	public long getMobile() {
		return mobile;
	}


	public void setMobile(long mobile) {
		this.mobile = mobile;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getPERMANENT_ADDRESS() {
		return PERMANENT_ADDRESS;
	}


	public void setPERMANENT_ADDRESS(String pERMANENT_ADDRESS) {
		PERMANENT_ADDRESS = pERMANENT_ADDRESS;
	}


	public String getCORRESPONDING_ADDRESS() {
		return CORRESPONDING_ADDRESS;
	}


	public void setCORRESPONDING_ADDRESS(String cORRESPONDING_ADDRESS) {
		CORRESPONDING_ADDRESS = cORRESPONDING_ADDRESS;
	}


	public String getAadhar_no() {
		return aadhar_no;
	}


	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}


	public String getAcc_type() {
		return acc_type;
	}


	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}


	public String getIFSC() {
		return IFSC;
	}


	public void setIFSC(String iFSC) {
		IFSC = iFSC;
	}


	public String getPhoto_path() {
		return photo_path;
	}


	public void setPhoto_path(String photo_path) {
		this.photo_path = photo_path;
	}


	public String getAadhar_path() {
		return aadhar_path;
	}


	public void setAadhar_path(String aadhar_path) {
		this.aadhar_path = aadhar_path;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getReason() {
		return reason;
	}


	public void setReason(String reason) {
		this.reason = reason;
	}


	@Override
	public String toString() {
		return "dr_Customers customer_id=" + customer_id + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", middlename=" + middlename + ", email=" + email + ", dateofbirth=" + dateofbirth + ", mobile="
				+ mobile + ", gender=" + gender + ", PERMANENT_ADDRESS=" + PERMANENT_ADDRESS
				+ ", CORRESPONDING_ADDRESS=" + CORRESPONDING_ADDRESS + ", aadhar_no=" + aadhar_no + ", acc_type="
				+ acc_type + ", IFSC=" + IFSC + ", photo_path=" + photo_path + ", aadhar_path=" + aadhar_path
				+ ", status=" + status + ", reason=" + reason ;
	}

	
	
}